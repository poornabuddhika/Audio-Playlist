package com.pavan.customlistfragment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.annotation.TargetApi;
import android.app.Fragment;
import android.app.ListFragment;
import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class MyListFragment extends ListFragment implements OnItemClickListener {

    String[] menutitles;
    String[] currency;
    TypedArray menuIcons;

    CustomAdapter adapter;
    //private List<RowItem> rowItems;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.list_fragment, null, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {

        super.onActivityCreated(savedInstanceState);

        menutitles = getResources().getStringArray(R.array.titles);
        currency = getResources().getStringArray(R.array.currancy);
        menuIcons = getResources().obtainTypedArray(R.array.icons);
        // Each row in the list stores country name, currency and flag
        List<HashMap<String, String>> rowItems = new ArrayList<HashMap<String, String>>();


        for (int i = 0; i < menutitles.length; i++) {
            HashMap<String, String> hm = new HashMap<String, String>();
            hm.put("txt", "" + menutitles[i]);
            hm.put("cur", "" + currency[i]);
            hm.put("flag", Integer.toString(menuIcons.getResourceId(i, -1)));

            //RowItem items = new RowItem(menutitles[i], menuIcons.getResourceId(i, -1));

            rowItems.add(hm);
        }

        String[] from = {"flag", "txt", "cur"};
        int[] to = {R.id.icon, R.id.title, R.id.cur};

        //adapter = new CustomAdapter(getActivity(), rowItems);


        // Instantiating an adapter to store each items
        // R.layout.listview_layout defines the layout of each item
        SimpleAdapter adapter = new SimpleAdapter(getActivity(), rowItems, R.layout.list_item, from, to);

        setListAdapter(adapter);

        getListView().setOnItemClickListener(this);


    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position,
                            long id) {

        // Getting the Container Layout of the ListView


        switch (position) {
            case 0: {
                playVideo("atavisipiritha");
            }
            break;
            case 1: {
                playVideo("rathana");
            }
            break;
            case 2: {
                playVideo("karaniyameththa");
            }
            break;
            case 3: {
                playVideo("bojjanga");
            }
            break;
            case 4: {
                playVideo("hickorydickorydock");
            }
            break;
            case 5: {
                playVideo("humptydumpty");
            }
            break;
            case 6: {
                playVideo("heydiddlediddle");
            }
            break;
            case 7: {
                playVideo("grandoldduke");
            }
        }

    }

	private void playVideo(String resourceName) {

		Intent videoPlaybackActivity = new Intent(getActivity(), AndroidMediaPlayerExample.class);
		int res=this.getResources().getIdentifier(resourceName, "raw","com.pavan.customlistfragment");
		videoPlaybackActivity.putExtra("fileRes", res);
		startActivity(videoPlaybackActivity);
	}

}




