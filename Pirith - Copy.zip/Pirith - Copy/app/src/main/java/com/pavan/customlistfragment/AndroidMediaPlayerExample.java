package com.pavan.customlistfragment;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

import static java.util.concurrent.TimeUnit.MINUTES;

/**
 * Created by poorna on 12/31/15.
 */


public class AndroidMediaPlayerExample extends Activity {

    private MediaPlayer mediaPlayer;
    public TextView  duration;
    private double timeElapsed = 0, finalTime = 0;
    private int forwardTime = 2000, backwardTime = 2000;
    private Handler durationHandler = new Handler();
    private SeekBar seekbar;
    int fileRes=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle e = getIntent().getExtras();
        if (e != null) {
            fileRes = e.getInt("fileRes");
        }
        //set the layout of the Activity
        setTitleAc();

        setContentView(R.layout.pirith_main);


        //initialize views
        initializeViews();
        play(getCurrentFocus());

    }
protected void setTitleAc()
{
    switch (fileRes) {
        case R.raw.atavisipiritha: {
            setTitle("Atavisi Piritha (අට විසි පිරිත)");
        }
        break;
        case R.raw.bojjanga: {
            setTitle("Bojjanga Piritha (බෝජ්ජංග පිරිත)");
        }
        break;
        case R.raw.karaniyameththa: {
            setTitle("karaniyameththa Piritha (කරණීයමෙත්ත කරණීයමෙත්ත සුත්රය)");
        }
        break;
        case R.raw.rathana: {
            setTitle("Rathana Suthraya (රතන සුත්රය)");
        }

    }
}


    protected void initializeViews() {

        playFileRes(fileRes);
    }
    private boolean playFileRes(int fileRes) {
        if (fileRes==0) {
           // stopPlaying();
            return false;
        } else {

           // songName = (TextView) findViewById(R.id.songName);
            //mediaPlayer = MediaPlayer.create(this, R.raw.dingdongbell);
            mediaPlayer = MediaPlayer.create(this, Uri.parse("android.resource://" + "com.pavan.customlistfragment" + "/" + fileRes));
            finalTime = mediaPlayer.getDuration();
            duration = (TextView) findViewById(R.id.songDuration);
            seekbar = (SeekBar) findViewById(R.id.seekBar);
          //  songName.setText("Pirith Gatha");

            seekbar.setMax((int) finalTime);
            seekbar.setClickable(false);


            return true;
        }
    }


    // play mp3 song
    public void play(View view)
    {
        mediaPlayer.start();
        timeElapsed = mediaPlayer.getCurrentPosition();
        seekbar.setProgress((int) timeElapsed);
        durationHandler.postDelayed(updateSeekBarTime, 100);
    }

    //handler to change seekBarTime
    private Runnable updateSeekBarTime = new Runnable()
    {
        @TargetApi(Build.VERSION_CODES.GINGERBREAD)

        public void run() {
            try {
                //get current position
                if(mediaPlayer!=null)
                {
                    timeElapsed = mediaPlayer.getCurrentPosition();
                    //set seekbar progress
                    seekbar.setProgress((int) timeElapsed);
                    //set time remaing
                    double timeRemaining = finalTime - timeElapsed;
                    duration.setText(String.format("%d min, %d sec", TimeUnit.MILLISECONDS.toMinutes((long) timeRemaining), TimeUnit.MILLISECONDS.toSeconds((long) timeRemaining) - MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes((long) timeRemaining))));

                    //repeat yourself that again in 100 miliseconds
                    durationHandler.postDelayed(this, 100);
                }
            }
            catch (Exception e)
            {
                Log.d("",e.toString());
            }
        }
    };

    // pause mp3 song
    public void pause(View view) {
        mediaPlayer.pause();
    }

    // go forward at forwardTime seconds
    public void forward(View view) {
        //check if we can go forward at forwardTime seconds before song endes
        if ((timeElapsed + forwardTime) <= finalTime) {
            timeElapsed = timeElapsed + forwardTime;

            //seek to the exact second of the track
            mediaPlayer.seekTo((int) timeElapsed);
        }
    }

    // go backwards at backwardTime seconds
    public void rewind(View view) {
        //check if we can go back at backwardTime seconds after song starts
        if ((timeElapsed - backwardTime) > 0) {
            timeElapsed = timeElapsed - backwardTime;

            //seek to the exact second of the track
            mediaPlayer.seekTo((int) timeElapsed);
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();

            }
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }



}
