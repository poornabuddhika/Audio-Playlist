package com.pavan.customlistfragment;

/**
 * Created by poorna on 12/24/15.
 */
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.MediaController;
import android.widget.VideoView;

/**
 * Created by poorna on 12/24/15.
 */


public class VideoPlayer extends Activity implements MediaPlayer.OnCompletionListener,MediaPlayer.OnPreparedListener{

    private VideoView mVV;
    private MediaController mediaControls;

    @Override
    public void onCreate(Bundle b) {

///////////////////////////
        if (mediaControls == null) {
            mediaControls = new MediaController(VideoPlayer.this);
        }
///////////////////////////////
        super.onCreate(b);

        setContentView(R.layout.videoplayer);

        int fileRes=0;
        Bundle e = getIntent().getExtras();
        if (e!=null) {
            fileRes = e.getInt("fileRes");
        }

        mVV = (VideoView)findViewById(R.id.myvideoview);


        mVV.setOnCompletionListener(this);
        mVV.setOnPreparedListener(this);
        //mVV.setOnTouchListener(this);

        if (!playFileRes(fileRes)) return;





        mVV.start();
        mVV.setMediaController(mediaControls);






    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        int fileRes = 0;
        Bundle e = getIntent().getExtras();
        if (e != null) {
            fileRes = e.getInt("fileRes");
        }
        playFileRes(fileRes);
    }

    private boolean playFileRes(int fileRes) {
        if (fileRes==0) {
            stopPlaying();
            return false;
        } else {
            mVV.setVideoURI(Uri.parse("android.resource://" + "com.pavan.customlistfragment"+ "/" +fileRes));
            //mVV.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/"  +"dingdongbell"));


            return true;
        }
    }

    public void stopPlaying() {
        mVV.stopPlayback();
        this.finish();
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        finish();
    }
    /*
        @Override
        public boolean onTouch(View v, MotionEvent event) {
          //  stopPlaying();
            return true;
        }

    */
    @Override
    public void onPrepared(MediaPlayer mp) {

        mp.setLooping(true);
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("Position", mVV.getCurrentPosition());
        mVV.pause();
    }
    private int position = 0;
    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        position = savedInstanceState.getInt("Position");
        mVV.seekTo(position);
    }





}
